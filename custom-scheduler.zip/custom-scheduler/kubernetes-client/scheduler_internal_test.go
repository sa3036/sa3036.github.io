package main

import "testing"


func TestClustering(t *testing.T) {
   //Update_clusters()
   t.Log(curServices)
   generateMockData()
   Deploy_clusters()		
}