### Changed part of prometheus go-client library in order to parse json easily.

### To use it:  
#### replace $GOPATH/src/github.com/prometheus/common/model/value.go with value.go in this folder  

#### $GOPATH/src/github.com/prometheus/common/model/metric.go with metric.go in this folder