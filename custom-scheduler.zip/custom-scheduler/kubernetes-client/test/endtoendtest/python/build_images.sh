sudo docker build -t khv129/app1 app1/
sudo docker build -t khv129/app2 app2/
sudo docker build -t khv129/app3 app3/
sudo docker build -t khv129/app4 app4/
sudo docker build -t khv129/app5 app5/

sudo docker push khv129/app1
sudo docker push khv129/app2
sudo docker push khv129/app3
sudo docker push khv129/app4
sudo docker push khv129/app5

