kubectl delete namespace custom
#kubectl delete -f /home/satish/real_world_applications/robot-shop/K8s/descriptors_custom/descriptors -n custom
