kubectl create namespace custom
kubectl label namespace custom istio-injection=enabled
#kubectl apply -f /home/satish/real_world_applications/robot-shop/K8s/descriptors -n custom
kubectl apply -f test/endtoendtest/python/robo_shop/descriptors/ -n custom
